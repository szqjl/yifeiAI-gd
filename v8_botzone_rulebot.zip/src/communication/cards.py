# 掼蛋 Botzone 卡牌编解码（纯 Python，无外部依赖）

BZ_RANK_STR = "A23456789TJQK"
BZ_SUIT_MAP = {0: "H", 1: "D", 2: "S", 3: "C"}
V8_SUIT_TO_BZ = {"H": 0, "D": 1, "S": 2, "C": 3}
V8_RANK_TO_BZ = {r: i for i, r in enumerate(BZ_RANK_STR)}
RANK_ORDER = {"2": 0, "3": 1, "4": 2, "5": 3, "6": 4, "7": 5, "8": 6,
              "9": 7, "T": 8, "J": 9, "Q": 10, "K": 11, "A": 12}
JOKER_RANK_ORDER = {"B": 16, "R": 17}


def bz_to_v8_card(bz_int: int) -> str:
    first_deck = bz_int % 54
    value = first_deck // 4
    suit_idx = first_deck % 4
    if value == 13:
        return "SB" if suit_idx in (0, 2) else "HR"
    rank = BZ_RANK_STR[value]
    suit = BZ_SUIT_MAP[suit_idx]
    return f"{suit}{rank}"


def v8_to_bz_int(v8_card: str, deck_offset: int = 0) -> int:
    suit_char = v8_card[0]
    rank_part = v8_card[1:] if len(v8_card) > 2 else v8_card[1]
    if rank_part in ("B", "R"):
        if rank_part == "B":
            value, suit_idx = 13, 0
        else:
            value, suit_idx = 13, 1
    else:
        suit_idx = V8_SUIT_TO_BZ.get(suit_char, 2)
        value = V8_RANK_TO_BZ.get(rank_part, 0)
    base = 54 * deck_offset
    return base + value * 4 + suit_idx


def bz_to_v8_cards(bz_card_list):
    return [bz_to_v8_card(c) for c in bz_card_list]


def v8_to_bz_cards(v8_card_list, deck_offset=0):
    return [v8_to_bz_int(c, deck_offset) for c in v8_card_list]


def card_rank(v8_card: str) -> str:
    return v8_card[1:] if len(v8_card) > 2 else v8_card[1]


def card_rank_order(v8_card: str, cur_rank: str = "2") -> int:
    r = card_rank(v8_card)
    if r == cur_rank:
        return 15
    return JOKER_RANK_ORDER.get(r, RANK_ORDER.get(r, -1))


def rank_to_order(rank: str, cur_rank: str = "2") -> int:
    if rank == cur_rank:
        return 15
    return JOKER_RANK_ORDER.get(rank, RANK_ORDER.get(rank, -1))


class CardTracker:
    def __init__(self):
        self.remaining = {}

    @classmethod
    def from_bz_hand(cls, bz_hand):
        ct = cls()
        for c in bz_hand:
            v8 = bz_to_v8_card(c)
            ct.remaining.setdefault(v8, []).append(c)
        return ct

    def remove(self, v8_card: str):
        pool = self.remaining.get(v8_card, [])
        if not pool:
            return None
        return pool.pop(0)

    def remove_multi(self, v8_cards):
        return [c for c in (self.remove(card) for card in v8_cards) if c is not None]

    def add(self, v8_card: str, bz_int: int):
        self.remaining.setdefault(v8_card, []).append(bz_int)

    def copy(self):
        ct = CardTracker()
        ct.remaining = {k: list(v) for k, v in self.remaining.items()}
        return ct
