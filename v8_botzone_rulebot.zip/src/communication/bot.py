# Botzone 掼蛋 Bot — 纯规则版 V8

from src.communication.cards import (
    bz_to_v8_cards, bz_to_v8_card, v8_to_bz_int,
    card_rank_order, rank_to_order,
    CardTracker,
)
from src.communication.actions import ActionListGenerator, classify_action, beats, make_action


class BotzoneGuanDanBot:
    def __init__(self):
        self.hand_cards = []
        self.card_tracker = None
        self.cur_rank = "2"
        self.action_gen = ActionListGenerator()
        self.player_id = 0
        self.self_rank = "2"
        self.oppo_rank = "2"

    def process(self, requests, responses):
        """Reconstruct state from all requests/responses, then handle the current request."""
        # Phase 1: Replay all completed request+response pairs
        replay_count = min(len(requests), len(responses))
        for i in range(replay_count):
            req = requests[i]
            resp = responses[i]
            self._replay(req, resp)

        # Phase 2: Handle the current request (last one without a response)
        if len(requests) > len(responses):
            current_req = requests[-1]
            return self._handle_current(current_req, responses)

        return "[]"

    def _replay(self, req, resp):
        """Replay a past request+response to reconstruct game state."""
        stage = req.get("stage", "")
        if stage == "deal":
            bz_hand = req.get("deliver", [])
            self.hand_cards = bz_to_v8_cards(bz_hand)
            self.card_tracker = CardTracker.from_bz_hand(bz_hand)
            self.player_id = req.get("your_id", self.player_id)
            level = req.get("global", {}).get("level", "2")
            self.cur_rank = level
            self.self_rank = level
            self.oppo_rank = level

        elif stage == "tribute":
            # resp is [card_id] — remove that card from hand
            if isinstance(resp, list) and len(resp) > 0:
                bz_card = resp[0]
                v8 = bz_to_v8_card(bz_card)
                if v8 in self.hand_cards:
                    self.hand_cards.remove(v8)
                    if self.card_tracker:
                        self.card_tracker.remove(v8)

        elif stage == "return":
            # First add received tribute card
            tribute_cards = req.get("global", {}).get("tribute_cards", {})
            for payer_id, bz_card in tribute_cards.items():
                if isinstance(bz_card, int) and bz_card >= 0:
                    v8 = bz_to_v8_card(bz_card)
                    if v8 not in self.hand_cards and v8 is not None:
                        self.hand_cards.append(v8)
                        if self.card_tracker:
                            self.card_tracker.add(v8, bz_card)
            # Then remove the returned card
            if isinstance(resp, list) and len(resp) > 0:
                bz_card = resp[0]
                v8 = bz_to_v8_card(bz_card)
                if v8 in self.hand_cards:
                    self.hand_cards.remove(v8)
                    if self.card_tracker:
                        self.card_tracker.remove(v8)
                else:
                    # Card might be from the tribute — just try to remove by V8 name
                    for c in list(self.hand_cards):
                        if c[1:] == v8[1:]:
                            self.hand_cards.remove(c)
                            break

        elif stage == "play":
            # Remove cards played from hand
            if isinstance(resp, list) and len(resp) > 0:
                played_bz = resp[0]
                if isinstance(played_bz, list):
                    for bz_card in played_bz:
                        v8 = bz_to_v8_card(bz_card)
                        if v8 in self.hand_cards:
                            self.hand_cards.remove(v8)
                            if self.card_tracker:
                                self.card_tracker.remove(v8)

    def _handle_current(self, req, prev_responses):
        """Handle the current request and return the response string."""
        stage = req.get("stage", "")
        if stage == "deal":
            return "[]"
        elif stage == "tribute":
            return self._do_tribute(req)
        elif stage == "return":
            return self._do_return(req)
        elif stage == "play":
            return self._do_play(req)
        return "[]"

    def _do_tribute(self, req):
        if not self.hand_cards:
            return "[]"
        hand_ordered = sorted(self.hand_cards,
                              key=lambda c: card_rank_order(c, self.cur_rank),
                              reverse=True)
        wild = f"H{self.cur_rank}"
        for card in hand_ordered:
            if card != wild:
                bz = self.card_tracker.remove(card) if self.card_tracker else None
                self.hand_cards.remove(card)
                if bz is not None:
                    return f"[{bz}]"
                return f"[{v8_to_bz_int(card)}]"
        return "[]"

    def _do_return(self, req):
        tribute_cards = req.get("global", {}).get("tribute_cards", {})
        for payer_id, bz_card in tribute_cards.items():
            if isinstance(bz_card, int) and bz_card >= 0:
                v8 = bz_to_v8_card(bz_card)
                if v8 not in self.hand_cards:
                    self.hand_cards.append(v8)
                    if self.card_tracker:
                        self.card_tracker.add(v8, bz_card)
        rank_order_10 = 8
        candidates = [c for c in self.hand_cards
                      if card_rank_order(c, self.cur_rank) <= rank_order_10]
        if not candidates:
            candidates = self.hand_cards[:]
        return_card = min(candidates, key=lambda c: card_rank_order(c, self.cur_rank))
        bz = self.card_tracker.remove(return_card) if self.card_tracker else None
        self.hand_cards.remove(return_card)
        if bz is not None:
            return f"[{bz}]"
        return f"[{v8_to_bz_int(return_card)}]"

    def _do_play(self, req):
        history = req.get("history", [])
        hand = self.hand_cards[:]

        greater_action = None
        for entry in history:
            if isinstance(entry, list):
                resp = entry[1] if len(entry) > 1 else [[], []]
            else:
                resp = entry.get("response", [[], []])
            action_cards = resp[0] if isinstance(resp, list) and len(resp) > 0 else []
            if action_cards:
                v8_action = classify_action(bz_to_v8_cards(action_cards), self.cur_rank)
                if v8_action and v8_action[0] != "PASS":
                    if greater_action is None or beats(v8_action, greater_action, self.cur_rank):
                        greater_action = v8_action

        self.action_gen.cur_rank = self.cur_rank
        if greater_action and greater_action[0] != "PASS":
            action_list = self.action_gen.generate_follow_actions(hand, greater_action)
        else:
            action_list = self.action_gen.generate_lead_actions(hand)

        if not action_list or len(action_list) <= 1:
            return "[[],[]]"

        chosen_idx = 0
        for i, a in enumerate(action_list):
            if a[0] != "PASS":
                chosen_idx = i
                break

        chosen = action_list[chosen_idx]
        if chosen[0] == "PASS":
            return "[[],[]]"

        v8_cards = chosen[2] if len(chosen) >= 3 else []
        bz_ints = []
        for v8_card in v8_cards:
            bz = self.card_tracker.remove(v8_card) if self.card_tracker else None
            if bz is not None:
                bz_ints.append(bz)
        if not bz_ints:
            bz_ints = [v8_to_bz_int(c) for c in v8_cards]

        for c in v8_cards:
            if c in self.hand_cards:
                self.hand_cards.remove(c)

        wild = f"H{self.cur_rank}"
        has_wild = any(c == wild for c in v8_cards)
        claim = bz_ints[:] if has_wild else []
        return f"[{bz_ints},{claim}]"
