# 掼蛋出牌列表生成器（纯 Python，无外部依赖）

from collections import Counter

from src.communication.cards import (
    card_rank, card_rank_order, rank_to_order,
    RANK_ORDER, JOKER_RANK_ORDER,
)

ACTION_TYPES_SIMPLE = ("Single", "Pair", "Trips")
ACTION_TYPES_COMPLEX = ("ThreeWithTwo", "ThreePair", "TwoTrips", "Straight", "StraightFlush", "Bomb")


def is_bomb(action):
    t = action[0] if isinstance(action, list) and len(action) >= 1 else ""
    return t in ("Bomb", "StraightFlush")


def make_action(action_type: str, rank: str, cards):
    return [action_type, rank, cards]


class ActionListGenerator:
    def __init__(self):
        self.cur_rank = "2"

    def generate_lead_actions(self, hand_cards):
        actions = []
        cards = sorted(hand_cards, key=lambda c: card_rank_order(c, self.cur_rank))
        rank_groups = self._group_by_rank(cards)
        suit_groups = self._group_by_suit(cards)

        ranks_sorted = sorted(rank_groups.keys(),
                              key=lambda r: rank_to_order(r, self.cur_rank))

        # Singles
        for r in ranks_sorted:
            for c in rank_groups[r]:
                actions.append(make_action("Single", r, [c]))

        # Pairs
        for r in ranks_sorted:
            cards_r = rank_groups[r]
            for i in range(0, len(cards_r) - 1, 2):
                actions.append(make_action("Pair", r, cards_r[i:i + 2]))

        # Trips
        for r in ranks_sorted:
            cards_r = rank_groups[r]
            if len(cards_r) >= 3:
                actions.append(make_action("Trips", r, cards_r[:3]))

        # Bombs (4+ of same rank)
        for r in ranks_sorted:
            cards_r = rank_groups[r]
            n = len(cards_r)
            if n >= 4:
                for size in range(4, n + 1):
                    actions.append(make_action("Bomb", r, cards_r[:size]))

        # ThreeWithTwo (trips + pair)
        for r in ranks_sorted:
            cards_r = rank_groups[r]
            if len(cards_r) < 3:
                continue
            trips = cards_r[:3]
            remaining = [c for c in cards if card_rank(c) != r]
            pair = self._find_best_pair(remaining, r)
            if pair:
                actions.append(make_action("ThreeWithTwo", r, trips + pair))

        # Straight (5 consecutive singles)
        straights = self._generate_straights(cards, rank_groups)
        for s in straights:
            high_r = max(s, key=lambda r: rank_to_order(r, self.cur_rank))
            # Pick one card of each rank for the straight
            straight_cards = []
            for r in s:
                straight_cards.append(rank_groups[r][0])
            actions.append(make_action("Straight", high_r, straight_cards))
            # StraightFlush if all same suit
            for suit, s_cards in suit_groups.items():
                suit_ranks = set(card_rank(c) for c in s_cards)
                if all(r in suit_ranks for r in s):
                    sf_cards = []
                    for r in s:
                        for c in s_cards:
                            if card_rank(c) == r:
                                sf_cards.append(c)
                                break
                    if len(sf_cards) == 5:
                        actions.append(make_action("StraightFlush", high_r, sf_cards))

        # ThreePair (3 consecutive pairs)
        three_pairs = self._generate_three_pairs(cards, rank_groups)
        for tp in three_pairs:
            high_r = max(tp, key=lambda r: rank_to_order(r, self.cur_rank))
            tp_cards = []
            for r in tp:
                tp_cards.extend(rank_groups[r][:2])
            actions.append(make_action("ThreePair", high_r, tp_cards))

        # TwoTrips (2 consecutive trips)
        two_trips = self._generate_two_trips(cards, rank_groups)
        for tt in two_trips:
            high_r = max(tt, key=lambda r: rank_to_order(r, self.cur_rank))
            tt_cards = []
            for r in tt:
                tt_cards.extend(rank_groups[r][:3])
            actions.append(make_action("TwoTrips", high_r, tt_cards))

        # StraightFlush by suit enumeration
        sf_by_suit = self._generate_straight_flushes_by_suit(cards, suit_groups)
        actions.extend(sf_by_suit)

        return actions

    def generate_follow_actions(self, hand_cards, greater_action):
        actions = []
        greater_type = greater_action[0]
        greater_rank = greater_action[1] if len(greater_action) >= 2 else ""
        greater_cards = greater_action[2] if len(greater_action) >= 3 else []
        n_greater = len(greater_cards)

        cards = sorted(hand_cards, key=lambda c: card_rank_order(c, self.cur_rank))
        rank_groups = self._group_by_rank(cards)
        suit_groups = self._group_by_suit(cards)
        ranks_sorted = sorted(rank_groups.keys(),
                              key=lambda r: rank_to_order(r, self.cur_rank))

        # PASS is always available
        actions.append(make_action("PASS", "PASS", []))

        if is_bomb(greater_action):
            # Must follow with a bigger bomb or straight flush
            for r in ranks_sorted:
                cards_r = rank_groups[r]
                n = len(cards_r)
                if n >= 4 and rank_to_order(r, self.cur_rank) > rank_to_order(greater_rank, self.cur_rank):
                    actions.append(make_action("Bomb", r, cards_r[:4]))
            for r in ranks_sorted:
                cards_r = rank_groups[r]
                n = len(cards_r)
                if n > 4:
                    for size in range(5, n + 1):
                        actions.append(make_action("Bomb", r, cards_r[:size]))
            # StraightFlush beats all normal bombs
            sf_by_suit = self._generate_straight_flushes_by_suit(cards, suit_groups)
            actions.extend(sf_by_suit)
            return actions

        if greater_type in ACTION_TYPES_SIMPLE:
            for r in ranks_sorted:
                cards_r = rank_groups[r]
                order_r = rank_to_order(r, self.cur_rank)
                order_g = rank_to_order(greater_rank, self.cur_rank)
                if order_r > order_g:
                    n = len(cards_r)
                    if greater_type == "Single" and n >= 1:
                        actions.append(make_action("Single", r, [cards_r[0]]))
                    elif greater_type == "Pair" and n >= 2:
                        actions.append(make_action("Pair", r, cards_r[:2]))
                    elif greater_type == "Trips" and n >= 3:
                        actions.append(make_action("Trips", r, cards_r[:3]))
        elif greater_type == "ThreeWithTwo":
            for r in ranks_sorted:
                cards_r = rank_groups[r]
                if len(cards_r) >= 3 and rank_to_order(r, self.cur_rank) > rank_to_order(greater_rank, self.cur_rank):
                    trips = cards_r[:3]
                    remaining = [c for c in cards if card_rank(c) != r]
                    pair = self._find_best_pair(remaining)
                    if pair:
                        actions.append(make_action("ThreeWithTwo", r, trips + pair))
        elif greater_type == "Straight":
            straights = self._generate_straights(cards, rank_groups)
            for s in straights:
                high_r = max(s, key=lambda r: rank_to_order(r, self.cur_rank))
                if rank_to_order(high_r, self.cur_rank) > rank_to_order(greater_rank, self.cur_rank):
                    s_cards = [rank_groups[r][0] for r in s]
                    actions.append(make_action("Straight", high_r, s_cards))
        elif greater_type == "ThreePair":
            three_pairs = self._generate_three_pairs(cards, rank_groups)
            for tp in three_pairs:
                high_r = max(tp, key=lambda r: rank_to_order(r, self.cur_rank))
                if rank_to_order(high_r, self.cur_rank) > rank_to_order(greater_rank, self.cur_rank):
                    tp_cards = []
                    for r in tp:
                        tp_cards.extend(rank_groups[r][:2])
                    actions.append(make_action("ThreePair", high_r, tp_cards))
        elif greater_type == "TwoTrips":
            two_trips = self._generate_two_trips(cards, rank_groups)
            for tt in two_trips:
                high_r = max(tt, key=lambda r: rank_to_order(r, self.cur_rank))
                if rank_to_order(high_r, self.cur_rank) > rank_to_order(greater_rank, self.cur_rank):
                    tt_cards = []
                    for r in tt:
                        tt_cards.extend(rank_groups[r][:3])
                    actions.append(make_action("TwoTrips", high_r, tt_cards))
        elif greater_type == "StraightFlush":
            sf_by_suit = self._generate_straight_flushes_by_suit(cards, suit_groups)
            for sf in sf_by_suit:
                sf_high = sf[1]
                if rank_to_order(sf_high, self.cur_rank) > rank_to_order(greater_rank, self.cur_rank):
                    actions.append(sf)

        # Bombs always available as follow actions
        for r in ranks_sorted:
            cards_r = rank_groups[r]
            n = len(cards_r)
            if n >= 4:
                for size in range(4, n + 1):
                    actions.append(make_action("Bomb", r, cards_r[:size]))
        sf_by_suit = self._generate_straight_flushes_by_suit(cards, suit_groups)
        actions.extend(sf_by_suit)

        return actions

    def _group_by_rank(self, cards):
        groups = {}
        for c in cards:
            r = card_rank(c)
            groups.setdefault(r, []).append(c)
        return groups

    def _group_by_suit(self, cards):
        groups = {}
        for c in cards:
            suit = c[0]
            groups.setdefault(suit, []).append(c)
        return groups

    def _find_best_pair(self, cards, exclude_rank=None):
        rank_groups = self._group_by_rank(cards)
        ranks = sorted(rank_groups.keys(), key=lambda r: rank_to_order(r, self.cur_rank), reverse=True)
        for r in ranks:
            if exclude_rank and r == exclude_rank:
                continue
            if len(rank_groups[r]) >= 2:
                return rank_groups[r][:2]
        return None

    def _generate_straights(self, cards, rank_groups):
        straights = []
        ranks = sorted(rank_groups.keys(), key=lambda r: rank_to_order(r, self.cur_rank))
        orders = [rank_to_order(r, self.cur_rank) for r in ranks]
        rank_by_order = {rank_to_order(r, self.cur_rank): r for r in ranks}
        for i in range(len(orders)):
            for j in range(i, len(orders)):
                if orders[j] - orders[i] == 4 and j - i == 4:
                    straight = [rank_by_order[o] for o in range(orders[i], orders[i] + 5)
                                if o in rank_by_order]
                    if len(straight) == 5:
                        straights.append(straight)
        return straights

    def _generate_three_pairs(self, cards, rank_groups):
        result = []
        ranks = sorted(rank_groups.keys(), key=lambda r: rank_to_order(r, self.cur_rank))
        for i in range(len(ranks) - 2):
            r1, r2, r3 = ranks[i], ranks[i + 1], ranks[i + 2]
            o1 = rank_to_order(r1, self.cur_rank)
            o2 = rank_to_order(r2, self.cur_rank)
            o3 = rank_to_order(r3, self.cur_rank)
            if o2 - o1 == 1 and o3 - o2 == 1:
                if len(rank_groups[r1]) >= 2 and len(rank_groups[r2]) >= 2 and len(rank_groups[r3]) >= 2:
                    result.append((r1, r2, r3))
        return result

    def _generate_two_trips(self, cards, rank_groups):
        result = []
        ranks = sorted(rank_groups.keys(), key=lambda r: rank_to_order(r, self.cur_rank))
        for i in range(len(ranks) - 1):
            r1, r2 = ranks[i], ranks[i + 1]
            o1 = rank_to_order(r1, self.cur_rank)
            o2 = rank_to_order(r2, self.cur_rank)
            if o2 - o1 == 1:
                if len(rank_groups[r1]) >= 3 and len(rank_groups[r2]) >= 3:
                    result.append((r1, r2))
        return result

    def _generate_straight_flushes_by_suit(self, cards, suit_groups):
        results = []
        for suit, s_cards in suit_groups.items():
            s_ranks = sorted(set(card_rank(c) for c in s_cards),
                             key=lambda r: rank_to_order(r, self.cur_rank))
            s_orders = [rank_to_order(r, self.cur_rank) for r in s_ranks]
            rank_by_order = {rank_to_order(r, self.cur_rank): r for r in s_ranks}
            for i in range(len(s_orders)):
                for j in range(i, len(s_orders)):
                    if s_orders[j] - s_orders[i] == 4 and j - i == 4:
                        sf_ranks = [rank_by_order[o] for o in range(s_orders[i], s_orders[i] + 5)
                                    if o in rank_by_order]
                        if len(sf_ranks) == 5:
                            high_r = max(sf_ranks, key=lambda r: rank_to_order(r, self.cur_rank))
                            sf_cards = []
                            for r in sf_ranks:
                                for c in s_cards:
                                    if card_rank(c) == r:
                                        sf_cards.append(c)
                                        break
                            results.append(make_action("StraightFlush", high_r, sf_cards))
        return results


def classify_action(cards, cur_rank="2"):
    if not cards:
        return make_action("PASS", "PASS", [])
    n = len(cards)
    ranks = [card_rank(c) for c in cards]
    suits = [c[0] for c in cards]
    rank_counts = Counter(ranks)
    most_common = rank_counts.most_common()

    if n == 1:
        return make_action("Single", ranks[0], cards)
    if n == 2 and len(most_common) == 1:
        return make_action("Pair", ranks[0], cards)
    if n == 3 and len(most_common) == 1:
        return make_action("Trips", ranks[0], cards)
    if len(most_common) == 1 and n >= 4:
        return make_action("Bomb", ranks[0], cards)
    if n >= 5:
        if is_consecutive(ranks, cur_rank) and len(set(suits)) == 1:
            high = max(ranks, key=lambda r: rank_to_order(r, cur_rank))
            return make_action("StraightFlush", high, cards)
        if is_consecutive(ranks, cur_rank):
            high = max(ranks, key=lambda r: rank_to_order(r, cur_rank))
            return make_action("Straight", high, cards)
    if n == 5 and 3 in rank_counts.values() and 2 in rank_counts.values():
        trip_rank = [r for r, c in most_common if c == 3][0]
        return make_action("ThreeWithTwo", trip_rank, cards)
    if n == 6:
        if all(c == 2 for r, c in most_common) and is_consecutive(
                [r for r, c in most_common], cur_rank):
            high = max([r for r, c in most_common],
                       key=lambda r: rank_to_order(r, cur_rank))
            return make_action("ThreePair", high, cards)
        if all(c == 3 for r, c in most_common) and len(most_common) == 2:
            high = max(most_common[0][0], most_common[1][0],
                       key=lambda r: rank_to_order(r, cur_rank))
            return make_action("TwoTrips", high, cards)
    return make_action("Free", ranks[0] if ranks else "2", cards)


def is_consecutive(ranks, cur_rank="2"):
    orders = sorted(set(rank_to_order(r, cur_rank) for r in ranks))
    if len(orders) < 5:
        return False
    for i in range(1, len(orders)):
        if orders[i] - orders[i - 1] != 1:
            return False
    return True


def beats(action, greater, cur_rank="2"):
    t1, r1 = action[0], action[1] if len(action) >= 2 else ""
    t2, r2 = greater[0], greater[1] if len(greater) >= 2 else ""
    if is_bomb(action) and not is_bomb(greater):
        return True
    if t1 == "StraightFlush" and t2 == "Bomb":
        return True
    if t1 == t2:
        return rank_to_order(r1, cur_rank) > rank_to_order(r2, cur_rank)
    return False
