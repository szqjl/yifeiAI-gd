# Botzone 掼蛋 Bot — 纯规则版 V8
# 用法: 将此 zip 上传至 Botzone，选择 "Python 3.6" 和 "简单交互"

import sys, json, traceback

from src.communication.bot import BotzoneGuanDanBot


def main():
    try:
        line = sys.stdin.readline()
        if not line:
            return
        data = json.loads(line)
        requests = data.get("requests", [])
        responses = data.get("responses", [])

        bot = BotzoneGuanDanBot()
        result = bot.process(requests, responses)
        sys.stdout.write(result + "\n")
        sys.stdout.flush()
    except Exception as e:
        sys.stderr.write(traceback.format_exc() + "\n")
        sys.stderr.flush()
        sys.stdout.write("[]\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
